# FPGA to AI Chip — accelerator lab

A signed INT8 / INT32 educational output-stationary array and bit-accurate Python exercises. Sources are original educational code, licensed MIT (LICENSE). Tested on 2026-09-13 with Python 3.9 and Icarus Verilog 13.0. No third-party Python packages are required.

## Run the reference and RTL checks

```sh
python3 -m unittest discover -s tests -v
python3 scripts/verify_top.py
python3 lessons.py spec-1
```

Install Icarus Verilog 13.0 or set IVERILOG and VVP to its executables. IVL_ROOT is optional for an extracted relocatable package. The RTL checks use deterministic seed 20260913. Generated temporary testbenches are compiled, executed and compared against explicit reference results.

## What is implemented and verified

- mac.sv: signed products, explicit sign extension, clear/reset priority, enabled accumulation.
- pipelined_mac.sv: registered product and valid state, INT32 accumulation, pipeline flush on clear/reset.
- elastic.sv: one-entry ready/valid buffer with simultaneous replacement.
- pe.sv and systolic_array.sv: globally stepped forwarding, operand-valid masks and local INT32 sums.
- accelerator_top.sv: host-loaded fixed operand buffers, dimension validation, globally stepped tile control, and INT32 output capture; 20 randomized integrated cases verified.
- operand_ram.sv: registered read, read-first same-address write behavior in the behavioral model.
- model.py: quantized epilogue, matrix/tile/wavefront oracle, bounded memory, functional command transport and a small MLP.

The model's DMA/host path is functional Python, not RTL AXI DMA. The integrated top accepts A bytes at addresses0–31 and B bytes at32–63, with padded strides8 and4. START snapshots M,N,K (1–4,1–4,1–8); writes and additional starts are ignored while busy. Enable advances the array, DONE follows captured outputs. The simple host-load interface is not AXI/MMIO. A board/system shell is needed for external memory, registers and physical I/O. The articles state these boundaries and teach how to extend the project.

## FPGA implementation exercise

```sh
vivado -mode batch -source fpga/build.tcl
```

The default part is a generic xc7a35tcsg324-1 target, override with FPGA_PART. This is core-only out-of-context synthesis/place/route with an illustrative 10-ns clock and 2-ns interface delays. It is not a board shell, board constraint file or hardware measurement. Inspect generated timing/resource reports before adapting a board. Vivado execution and FPGA hardware deployment have not been performed in this release.

## Educational ASIC exercise

From a supported, pinned OpenROAD-flow-scripts checkout, run:

```sh
make -C flow DESIGN_CONFIG=/absolute/path/to/accelerator-lab/asic/config.mk
```

Nangate45 is an educational standard-cell target. The included core has no instantiated SRAM macro, pad ring, scan insertion or production signoff package. The flow is an exercise configuration; physical implementation and DRC/LVS/STA reports have not been produced in this release. Foundry fabrication requires an appropriate PDK, permitted models, full-chip integration and signoff beyond this core.

## Release evidence

reports/rtl-verification.json records the executed RTL checks. Python tests cover signed extremes, irregular tiles, memory/command bounds, numerical rounding and small inference. Exercises produce their own deterministic JSON artifacts. Report generated implementation or board measurements only after performing those steps.
