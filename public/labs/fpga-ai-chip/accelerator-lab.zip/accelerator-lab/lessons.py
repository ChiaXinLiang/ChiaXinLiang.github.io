"""Run a named, deterministic exercise. Scope is explicit in every artifact."""
from pathlib import Path
import json,sys,random,math,hashlib,struct
from model import *
ROOT=Path(__file__).parent
CODES=['spec-1','logic-1','number-1','rtl-1','verify-1','pipe-1','stream-1','pe-1','array-1','dataflow-1','tile-1','post-1','buffer-1','dma-1','overlap-1','control-1','fpga-1','host-1','inference-1','measure-1','portable-1','physical-1','signoff-1','release-1']

def split_axi_bursts(addr,length,max_bytes=256,boundary=4096):
 if addr<0 or length<0 or max_bytes<=0:raise ValueError('invalid burst request')
 result=[]
 while length:
  count=min(length,max_bytes,boundary-addr%boundary);result.append((addr,count));addr+=count;length-=count
 return result

def overlap_schedule(loads,computes):
 assert len(loads)==len(computes)
 # Two buffers; loading i may not overwrite i-2 before its compute ends.
 load_end=compute_end=0;ends=[];trace=[]
 for i,(l,c) in enumerate(zip(loads,computes)):
  start=max(load_end,ends[i-2] if i>=2 else 0);load_end=start+l
  cs=max(load_end,compute_end);compute_end=cs+c;ends.append(compute_end)
  trace.append(dict(tile=i,buffer=i%2,load=[start,load_end],compute=[cs,compute_end]))
 return trace

def exercise(code):
 a=[[1,2],[3,4]];b=[[5,6],[7,8]]
 scope='Deterministic software exercise; see reports/rtl-verification.json for executed RTL tests.'
 if code=='spec-1':result=dict(m=4,n=4,k=8,input_bytes=32,weight_bytes=32,output_bytes=64,useful_macs=128,accumulator='INT32')
 elif code=='logic-1':
  state='IDLE';count=0;trace=[]
  for cycle,(start,step,ack) in enumerate([(1,0,0),(0,1,0),(0,0,0),(0,1,0),(0,1,0),(0,0,1)]):
   if state=='IDLE' and start:state='RUN';count=0
   elif state=='RUN' and step:
    count+=1
    if count==3:state='DONE'
   elif state=='DONE' and ack:state='IDLE';count=0
   trace.append(dict(cycle=cycle,state=state,count=count))
  result=trace
 elif code=='number-1':result=dict(max_positive_product=(-128)*(-128),k=8,max_sum=131072,min_signed_bits=19,rounding='nearest ties away from zero')
 elif code in ['rtl-1','verify-1','pipe-1','stream-1','buffer-1']:result=json.loads((ROOT/'reports/rtl-verification.json').read_text())
 elif code=='pe-1':result=dict(products=[6,-20,-14],sum=-28,forwarding='one registered hop per accepted global step')
 elif code=='array-1':
  result,events=array_model(a,b);result=dict(output=result,steps=len(events),active_contributions=events)
 elif code=='dataflow-1':result=dict(workload=dict(m=4,n=4,k=8),external_once_bytes=128,scalar_no_reuse_input_bytes=256,local_products=128,note='OS/WS comparison requires matching buffer boundaries and a separate legal WS schedule; this release implements OS.')
 elif code=='tile-1':
  rng=random.Random(42);a=[[rng.randint(-3,3) for _ in range(7)] for _ in range(5)];b=[[rng.randint(-3,3) for _ in range(6)] for _ in range(7)]
  got=tiled_matmul(a,b);assert got==matmul(a,b);result=dict(shape=[5,6,7],output=got,exact_match=True)
 elif code=='post-1':result=dict(input=[-8,3,300],relu_then_shift1=[epilogue(x,shift=1) for x in [-8,3,300]],negative_tie=round_shift_away(-3,1))
 elif code=='dma-1':result=dict(start=4080,length=600,bursts=split_axi_bursts(4080,600),scope='AXI-style byte-range splitting model; not an RTL AXI master')
 elif code=='overlap-1':result=overlap_schedule([100]*4,[150]*4)
 elif code in ['control-1','host-1']:
  mem=Memory();mem.write(0,struct.pack('4b',1,2,3,4));mem.write(64,struct.pack('4b',5,6,7,8));dev=Accelerator(mem)
  result=dict(output=dev.submit(Command(0,64,128,2,2,2)),done=dev.done,output_bytes=list(mem.read(128,16)),scope='Functional memory/host transport, not RTL register/DMA integration')
 elif code=='inference-1':
  h,y=mlp([[1,2,-1,3]],[[1,0,-1,2],[0,1,2,0],[1,1,0,-1],[2,0,1,1]],[[1,-1],[2,1],[-1,2],[1,0]])
  result=dict(hidden=h,logits=y,argmax=max(range(len(y[0])),key=lambda j:y[0][j]),scope='Numerical demonstration, no trained accuracy claim')
 elif code=='measure-1':result=dict(useful_macs=128,ideal_global_steps=14,available_mac_slots=224,ideal_utilization=128/224,scope='Analytic no-stall wavefront model, not measured FPGA throughput',board_power_watts=None)
 elif code=='fpga-1':result=dict(script='fpga/build.tcl',mode='core-only out-of-context',default_part='xc7a35tcsg324-1',clock_period_ns=10,tool_run=False,board_run=False,next='Run Vivado, inspect reports, then integrate a documented board shell.')
 elif code=='portable-1':result=dict(core='rtl/systolic_array.sv',primitive_dependencies=[],memory_wrapper='rtl/operand_ram.sv',scope='Behavioral read-first wrapper; select a permitted ASIC macro and verify its timing separately.')
 elif code=='physical-1':result=dict(config='asic/config.mk',platform='nangate45',tool_run=False,gds_produced=False,scope='Educational core configuration, no pad ring or production signoff')
 elif code=='signoff-1':result=dict(single_clock_core=True,reset='synchronous active high',rtl_tests_pass=True,sta_run=False,drc_run=False,lvs_run=False,scan_inserted=False,scope='Release checklist, unperformed checks remain unclosed.')
 elif code=='release-1':result={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob('*')) if p.is_file() and p.suffix in ['.sv','.py','.tcl','.sdc','.mk'] and '__pycache__' not in p.parts}
 else:raise ValueError('unknown lesson')
 return dict(lesson=code,scope=scope,result=result)
if __name__=='__main__':
 codes=CODES if len(sys.argv)>1 and sys.argv[1]=='all' else sys.argv[1:]
 if not codes:raise SystemExit('Usage: python3 lessons.py CODE | all')
 for code in codes:
  artifact=exercise(code);(ROOT/'reports'/f'{code}.json').write_text(json.dumps(artifact,indent=2)+'\n')
  print(json.dumps(artifact,indent=2))
