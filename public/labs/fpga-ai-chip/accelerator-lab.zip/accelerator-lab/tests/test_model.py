import unittest,random,struct,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from model import *
class ModelTests(unittest.TestCase):
 def test_known_matrix(self):self.assertEqual(matmul([[1,2],[3,4]],[[5,6],[7,8]]),[[19,22],[43,50]])
 def test_signed_extremes(self):self.assertEqual(matmul([[-128]*8],[[-128] for _ in range(8)]),[[131072]])
 def test_tiled_shapes(self):
  rng=random.Random(41)
  for m,n,k in [(1,1,1),(4,4,8),(5,6,7),(9,3,11),(3,9,2)]:
   a=[[rng.randint(-128,127) for _ in range(k)] for _ in range(m)];b=[[rng.randint(-128,127) for _ in range(n)] for _ in range(k)]
   self.assertEqual(tiled_matmul(a,b),matmul(a,b))
 def test_rounding(self):
  for x,y in [(3,2),(-3,-2),(1,1),(-1,-1),(2,1),(-2,-1)]:self.assertEqual(round_shift_away(x,1),y)
  self.assertEqual([epilogue(x,shift=1) for x in [-8,3,300]],[0,2,127])
 def test_memory(self):
  mem=Memory(64)
  for addr,length,align in [(-1,1,1),(64,1,1),(2,4,4),(2,100,1)]:
   with self.assertRaises(ValueError):mem.validate(addr,length,align)
 def test_host(self):
  mem=Memory();mem.write(0,struct.pack('4b',1,2,3,4));mem.write(64,struct.pack('4b',5,6,7,8));dev=Accelerator(mem)
  self.assertEqual(dev.submit(Command(0,64,128,2,2,2)),[[19,22],[43,50]]);self.assertTrue(dev.done)
  self.assertEqual(struct.unpack('<4i',mem.read(128,16)),(19,22,43,50))
 def test_invalid_command_no_writes(self):
  mem=Memory();before=bytes(mem.data);dev=Accelerator(mem)
  with self.assertRaises(ValueError):dev.submit(Command(0,64,2,2,2,2))
  self.assertEqual(bytes(mem.data),before)
 def test_array_trace(self):
  a=[[1]*8 for _ in range(4)];b=[[1]*4 for _ in range(8)];result,events=array_model(a,b)
  self.assertEqual(result,[[8]*4 for _ in range(4)]);self.assertEqual(len(events),14);self.assertEqual(sum(map(len,events)),128)
 def test_small_mlp(self):
  x=[[1,2,-1,3]];w1=[[1,0,-1,2],[0,1,2,0],[1,1,0,-1],[2,0,1,1]];w2=[[1,-1],[2,1],[-1,2],[1,0]]
  h,y=mlp(x,w1,w2);self.assertEqual(h,[[3,1,3,3]]);self.assertEqual(y,[[5,4]])
if __name__=='__main__':unittest.main()
