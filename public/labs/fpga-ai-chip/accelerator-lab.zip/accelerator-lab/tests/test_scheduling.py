import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lessons import split_axi_bursts,overlap_schedule,CODES,exercise
class ScheduleTests(unittest.TestCase):
 def test_burst_boundaries_and_byte_conservation(self):
  for addr,length in [(4080,600),(0,513),(4095,3),(8192,0)]:
   bursts=split_axi_bursts(addr,length);self.assertEqual(sum(n for a,n in bursts),length)
   cursor=addr
   for a,n in bursts:self.assertEqual(a,cursor);self.assertLessEqual(n,256);self.assertLessEqual(a%4096+n,4096);cursor+=n
 def test_double_buffer_ownership(self):
  for loads,computes in [([100]*8,[150]*8),([250,1,10,100],[5,200,30,1])]:
   t=overlap_schedule(loads,computes)
   for i,x in enumerate(t):
    self.assertGreaterEqual(x['compute'][0],x['load'][1])
    if i>=2:self.assertGreaterEqual(x['load'][0],t[i-2]['compute'][1])
    if i:self.assertGreaterEqual(x['compute'][0],t[i-1]['compute'][1])
 def test_lessons_execute_and_scope(self):
  for code in CODES:self.assertEqual(exercise(code)['lesson'],code)
if __name__=='__main__':unittest.main()
