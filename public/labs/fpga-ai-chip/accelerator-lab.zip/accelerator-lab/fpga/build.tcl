# Core-only out-of-context implementation. No board pins or bitstream claim.
set lab [file normalize [file join [file dirname [info script]] ..]]
set part xc7a35tcsg324-1
if {[info exists ::env(FPGA_PART)]} {set part $::env(FPGA_PART)}
file mkdir [file join $lab reports fpga]
read_verilog -sv [list [file join $lab rtl pe.sv] [file join $lab rtl systolic_array.sv] [file join $lab rtl accelerator_top.sv]]
synth_design -top accelerator_top -mode out_of_context -part $part
create_clock -name core_clk -period 10.0 [get_ports clk]
set_input_delay 2.0 -clock core_clk [get_ports -filter {DIRECTION == IN && NAME != clk}]
set_output_delay 2.0 -clock core_clk [get_ports -filter {DIRECTION == OUT}]
opt_design
place_design
route_design
report_utilization -file [file join $lab reports fpga utilization.rpt]
report_timing_summary -file [file join $lab reports fpga timing.rpt]
report_power -file [file join $lab reports fpga power_estimate.rpt]
write_checkpoint -force [file join $lab reports fpga accelerator_routed.dcp]
