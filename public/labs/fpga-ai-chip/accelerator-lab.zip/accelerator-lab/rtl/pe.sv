module pe(input logic clk,rst,clear,step,
 input logic signed [7:0] a_in,b_in,input logic av_in,bv_in,
 output logic signed [7:0] a_out,b_out,output logic av_out,bv_out,
 output logic signed [31:0] sum);
 wire signed [15:0] product=$signed(a_in)*$signed(b_in);
 always_ff @(posedge clk)begin
  if(rst || clear)begin a_out<=0;b_out<=0;av_out<=0;bv_out<=0;sum<=0;end
  else if(step)begin
   a_out<=a_in;b_out<=b_in;av_out<=av_in;bv_out<=bv_in;
   if(av_in && bv_in)sum<=sum+{{16{product[15]}},product};
  end
 end
endmodule
