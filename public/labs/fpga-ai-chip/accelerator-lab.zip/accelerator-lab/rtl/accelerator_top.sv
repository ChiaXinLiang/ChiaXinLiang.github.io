// Small complete tile accelerator. Host-load interface is not AXI/MMIO/DMA.
// A uses four padded rows of 8 bytes at addresses 0..31.
// B uses eight padded rows of 4 bytes at addresses 32..63.
module accelerator_top(input logic clk,rst,start,step_enable,wr_en,
 input logic [5:0] wr_addr,input logic signed [7:0] wr_data,
 input logic [2:0] m,n,input logic [3:0] k,input logic [3:0] rd_addr,
 output logic signed [31:0] rd_data,output logic busy,done,error);
 localparam IDLE=0,CLEAR=1,RUN=2,CAPTURE=3,FINISHED=4;
 logic [2:0] state;logic [2:0] mq,nq;logic [3:0] kq;
 logic [4:0] t;
 logic signed [7:0] amem[0:3][0:7],bmem[0:7][0:3];
 logic [31:0] a_rows,b_cols;logic [3:0] a_valid,b_valid;
 wire [511:0] results;logic signed [31:0] output_mem[0:15];
 wire clear=(state==CLEAR);wire step=(state==RUN && step_enable);
 integer i,j,q;
 assign busy=(state==CLEAR || state==RUN || state==CAPTURE);
 assign rd_data=output_mem[rd_addr];
 always_comb begin
  a_rows=0;b_cols=0;a_valid=0;b_valid=0;
  for(i=0;i<4;i=i+1)begin
   q=$signed({1'b0,t})-i;
   if(state==RUN && i<mq && q>=0 && q<kq)begin a_rows[i*8+:8]=amem[i][q];a_valid[i]=1;end
  end
  for(j=0;j<4;j=j+1)begin
   q=$signed({1'b0,t})-j;
   if(state==RUN && j<nq && q>=0 && q<kq)begin b_cols[j*8+:8]=bmem[q][j];b_valid[j]=1;end
  end
 end
 systolic_array array_core(.clk(clk),.rst(rst),.clear(clear),.step(step),
  .a_rows(a_rows),.b_cols(b_cols),.a_valid(a_valid),.b_valid(b_valid),.results(results));
 integer x;
 always_ff @(posedge clk)begin
  if(rst)begin state<=IDLE;t<=0;mq<=0;nq<=0;kq<=0;done<=0;error<=0;end
  else begin
   if(wr_en && !busy)begin
    if(wr_addr<32)amem[wr_addr>>3][wr_addr&7]<=wr_data;
    else bmem[(wr_addr-32)>>2][wr_addr&3]<=wr_data;
   end
   case(state)
    IDLE,FINISHED:if(start)begin
     done<=0;error<=0;
     if(m==0 || m>4 || n==0 || n>4 || k==0 || k>8)begin error<=1;state<=FINISHED;end
     else begin mq<=m;nq<=n;kq<=k;t<=0;state<=CLEAR;end
    end
    CLEAR:state<=RUN;
    RUN:if(step_enable)begin
     if(t==kq+5)state<=CAPTURE;
     else t<=t+1;
    end
    CAPTURE:begin
     for(x=0;x<16;x=x+1)output_mem[x]<=results[x*32+:32];
     done<=1;state<=FINISHED;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
