module operand_ram #(parameter W=8,DEPTH=64,AW=$clog2(DEPTH))(
 input logic clk,wr_en,input logic [AW-1:0] wr_addr,rd_addr,
 input logic [W-1:0] wr_data,output logic [W-1:0] rd_data);
 logic [W-1:0] mem[0:DEPTH-1];
 // Registered read; same-address read/write returns the previous value.
 always_ff @(posedge clk)begin
  if(wr_en)mem[wr_addr]<=wr_data;
  rd_data<=mem[rd_addr];
 end
endmodule
