module mac #(parameter W=8, ACC=32)(input logic clk,rst,clear,en,
 input logic signed [W-1:0] a,b, output logic signed [ACC-1:0] sum);
 wire signed [2*W-1:0] product=$signed(a)*$signed(b);
 wire signed [ACC-1:0] extended={{(ACC-2*W){product[2*W-1]}},product};
 always_ff @(posedge clk) begin
  if(rst || clear) sum<='0;
  else if(en) sum<=sum+extended;
 end
endmodule
