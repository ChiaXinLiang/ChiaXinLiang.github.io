module systolic_array #(parameter R=4,C=4)(input logic clk,rst,clear,step,
 input logic [R*8-1:0] a_rows,input logic [C*8-1:0] b_cols,
 input logic [R-1:0] a_valid,input logic [C-1:0] b_valid,
 output wire [R*C*32-1:0] results);
 wire signed [7:0] ah[0:R-1][0:C],bv[0:R][0:C-1];
 wire va[0:R-1][0:C],vb[0:R][0:C-1];
 genvar i,j;
 generate for(i=0;i<R;i=i+1)begin:rows
  assign ah[i][0]=a_rows[i*8+:8];assign va[i][0]=a_valid[i];
  for(j=0;j<C;j=j+1)begin:cols
   pe cell_pe(.clk(clk),.rst(rst),.clear(clear),.step(step),
    .a_in(ah[i][j]),.b_in(bv[i][j]),.av_in(va[i][j]),.bv_in(vb[i][j]),
    .a_out(ah[i][j+1]),.b_out(bv[i+1][j]),.av_out(va[i][j+1]),.bv_out(vb[i+1][j]),
    .sum(results[(i*C+j)*32+:32]));
  end
 end
 for(j=0;j<C;j=j+1)begin:inputs_b
  assign bv[0][j]=b_cols[j*8+:8];assign vb[0][j]=b_valid[j];
 end endgenerate
endmodule
