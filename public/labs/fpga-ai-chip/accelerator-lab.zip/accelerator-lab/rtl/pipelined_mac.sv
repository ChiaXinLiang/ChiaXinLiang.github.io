module pipelined_mac(input logic clk,rst,clear,en,
 input logic signed [7:0] a,b,output logic signed [31:0] sum);
 logic signed [15:0] product_q;logic product_valid;
 always_ff @(posedge clk)begin
  if(rst || clear)begin sum<=0;product_q<=0;product_valid<=0;end
  else begin
   product_valid<=en;
   if(en)product_q<=$signed(a)*$signed(b);
   if(product_valid)sum<=sum+{{16{product_q[15]}},product_q};
  end
 end
endmodule
