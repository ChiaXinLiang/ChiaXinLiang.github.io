from pathlib import Path
import subprocess,tempfile,os,random,json,sys,shutil
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));from model import matmul
iverilog=os.environ.get('IVERILOG',shutil.which('iverilog') or '')
vvp=os.environ.get('VVP',shutil.which('vvp') or '')
if not iverilog or not vvp:raise SystemExit('Set IVERILOG and VVP or install Icarus Verilog 13.0.')
flags=['-B',os.environ['IVL_ROOT']] if os.environ.get('IVL_ROOT') else []
rng=random.Random(20260913);report={'seed':20260913,'tests':{},'simulator':'Icarus Verilog 13.0','scope':'RTL simulation only; no FPGA board or ASIC physical implementation measured'}
def run(name,body,modules):
 with tempfile.TemporaryDirectory() as d:
  tb=Path(d)/'tb.sv';tb.write_text(body);binary=Path(d)/'test.vvp'
  subprocess.run([iverilog,*flags,'-g2012','-s','tb','-o',str(binary),*[str(root/'rtl'/m) for m in modules],str(tb)],check=True,capture_output=True,text=True)
  p=subprocess.run([vvp,str(binary)],check=True,capture_output=True,text=True)
  if 'FAIL' in p.stdout:raise AssertionError(p.stdout)
  return p.stdout
header='module tb; reg clk=0,rst=1; task tick; begin #5;clk=1;#1;#4;clk=0;end endtask\n'
body=header+'reg clear=0,en=0; reg signed [7:0] a,b;wire signed[31:0] sum;mac dut(.*);initial begin a=0;b=0;tick;rst=0;\n';expected=0
for i in range(250):
 a,b=rng.randint(-128,127),rng.randint(-128,127);en=int(rng.random()>.25);clear=int(i%53==0);expected=0 if clear else expected+a*b*en
 body+=f'a={a};b={b};en={en};clear={clear};tick;if(sum!==32\'sd{expected})begin $display("FAIL MAC {i}");$fatal;end\n'.replace("32'sd-","-32'sd")
body+='$display("PASS mac");$finish;end endmodule\n';run('mac',body,['mac.sv']);report['tests']['mac_vectors']=250
body=header+'reg clear=0,en=0;reg signed[7:0] a,b;wire signed[31:0] sum;pipelined_mac dut(.*);initial begin a=0;b=0;tick;rst=0;\n';expected=0;pending=0
for i in range(250):
 a,b=rng.randint(-128,127),rng.randint(-128,127);en=int(rng.random()>.25);clear=int(i%47==0)
 if clear:expected=0;pending=0
 else:expected+=pending;pending=a*b if en else 0
 body+=f'a={a};b={b};en={en};clear={clear};tick;if(sum!==32\'sd{expected})begin $display("FAIL PIPE {i}");$fatal;end\n'.replace("32'sd-","-32'sd")
body+='$display("PASS pipeline");$finish;end endmodule';run('pipe',body,['pipelined_mac.sv']);report['tests']['pipeline_vectors']=250
body=header+'reg in_valid=0,out_ready=0;reg[31:0]in_data=0;wire in_ready,out_valid;wire[31:0]out_data;elastic dut(.*);initial begin tick;rst=0;\n';queue=[];value=0;offered=False;stalls=0
for i in range(500):
 ready=int(rng.random()>.4) if i<450 else 1
 if not offered and i<450 and rng.random()>.2:offered=True
 inv=int(offered);outvalid=bool(queue);inready=not outvalid or bool(ready)
 if outvalid and ready:
  exp=queue.pop(0);body+=f'if(!out_valid || out_data!==32\'d{exp})begin $display("FAIL STREAM {i}");$fatal;end\n'
 if inv and inready:queue.append(value)
 elif inv:stalls+=1
 body+=f'in_valid={inv};in_data=32\'d{value};out_ready={ready};tick;\n'
 if inv and inready:value+=1;offered=False
body+='$display("PASS elastic");$finish;end endmodule';run('elastic',body,['elastic.sv']);assert not queue;report['tests']['stream_cycles']=500;report['tests']['backpressure_cycles']=stalls
body=header+'reg clear=0,step=0;reg[31:0]a_rows=0,b_cols=0;reg[3:0]a_valid=0,b_valid=0;wire[511:0]results;systolic_array dut(.*);initial begin tick;rst=0;\n';cases=0;global_stalls=0
for m,n,k in [(2,2,2),(4,4,8),(3,2,7),(1,4,3)]+[(rng.randint(1,4),rng.randint(1,4),rng.randint(1,12)) for _ in range(36)]:
 a=[[rng.randint(-128,127) for _ in range(k)] for _ in range(m)];b=[[rng.randint(-128,127) for _ in range(n)] for _ in range(k)];exp=matmul(a,b)
 body+='clear=1;step=0;tick;clear=0;\n'
 for t in range(k+6):
  ar=bc=av=bv=0
  for i in range(m):
   q=t-i
   if 0<=q<k:ar|=(a[i][q]&255)<<(8*i);av|=1<<i
  for j in range(n):
   q=t-j
   if 0<=q<k:bc|=(b[q][j]&255)<<(8*j);bv|=1<<j
  body+=f'a_rows=32\'h{ar:08x};b_cols=32\'h{bc:08x};a_valid=4\'h{av:x};b_valid=4\'h{bv:x};\n'
  if rng.random()<.3:body+='step=0;tick;\n';global_stalls+=1
  body+='step=1;tick;\n'
 for i in range(4):
  for j in range(4):
   x=exp[i][j] if i<m and j<n else 0
   literal=("-" if x<0 else '')+f"32'sd{abs(x)}"
   body+=f'if($signed(results[{(i*4+j)*32}+:32])!=={literal})begin $display("FAIL ARRAY {cases} {i} {j}");$fatal;end\n'
 cases+=1
body+='$display("PASS array");$finish;end endmodule';run('array',body,['pe.sv','systolic_array.sv']);report['tests']['array_cases']=cases;report['tests']['global_stall_cycles']=global_stalls
body=header+'reg wr_en=0;reg[5:0]wr_addr=0,rd_addr=0;reg[7:0]wr_data=0;wire[7:0]rd_data;operand_ram dut(.*);initial begin tick;rst=0;wr_en=1;wr_addr=3;wr_data=17;rd_addr=0;tick;wr_en=0;rd_addr=3;tick;if(rd_data!==17)$fatal;wr_en=1;wr_addr=3;wr_data=99;tick;if(rd_data!==17)$fatal;wr_en=0;tick;if(rd_data!==99)$fatal;$display("PASS RAM");$finish;end endmodule';run('ram',body,['operand_ram.sv']);report['tests']['registered_ram_read_first']=True
(root/'reports/rtl-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
