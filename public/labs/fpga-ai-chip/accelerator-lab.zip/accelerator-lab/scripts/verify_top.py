from pathlib import Path
import sys,json,random
sys.path.insert(0,str(Path(__file__).parent))
from verify_rtl import run,header,root,report
sys.path.insert(0,str(root));from model import matmul
rng=random.Random(73)
body=header+'reg start=0,step_enable=1,wr_en=0;reg[5:0]wr_addr=0;reg signed[7:0]wr_data=0;reg[2:0]m=0,n=0;reg[3:0]k=0,rd_addr=0;wire signed[31:0]rd_data;wire busy,done,error;accelerator_top dut(.*);initial begin tick;rst=0;\n'
for case in range(20):
 mm,nn,kk=rng.randint(1,4),rng.randint(1,4),rng.randint(1,8);a=[[rng.randint(-128,127) for _ in range(kk)] for _ in range(mm)];b=[[rng.randint(-128,127) for _ in range(nn)] for _ in range(kk)]
 for i,row in enumerate(a):
  for j,x in enumerate(row):body+=f'wr_en=1;wr_addr={i*8+j};wr_data={x};tick;\n'
 for i,row in enumerate(b):
  for j,x in enumerate(row):body+=f'wr_en=1;wr_addr={32+i*4+j};wr_data={x};tick;\n'
 body+=f'wr_en=0;m={mm};n={nn};k={kk};start=1;tick;start=0;tick;\n'
 body+='step_enable=0;start=1;wr_en=1;wr_addr=0;wr_data=99;m=0;n=0;k=0;tick;if(!busy || error)$fatal;start=0;wr_en=0;\n'
 for t in range(kk+6):
  if rng.random()<.3:body+='step_enable=0;tick;\n'
  body+='step_enable=1;tick;\n'
 body+='tick;if(!done || error)$fatal;\n';expected=matmul(a,b)
 for i in range(4):
  for j in range(4):
   x=expected[i][j] if i<mm and j<nn else 0;literal=('-' if x<0 else '')+f"32'sd{abs(x)}"
   body+=f'rd_addr={i*4+j};#1;if(rd_data!=={literal})begin $display("FAIL TOP {case} {i} {j}");$fatal;end\n'
body+='m=0;start=1;tick;start=0;if(!error || done || busy)$fatal;$display("PASS TOP");$finish;end endmodule'
run('top',body,['pe.sv','systolic_array.sv','accelerator_top.sv']);report['tests']['integrated_tile_top_cases']=20;report['tests']['invalid_top_dimensions']=True;report['tests']['busy_start_and_write_ignored']=True;report['tests']['dimension_snapshot']=True;(root/'reports/rtl-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS integrated controller/memory/array top: 20 cases plus invalid dimensions')
