"""Bit-accurate teaching model. No third-party Python packages required."""
from dataclasses import dataclass
import struct

def check_int8(x):
 if not isinstance(x,int) or not -128<=x<=127:raise ValueError('INT8 range')
 return x

def round_shift_away(x,shift):
 if shift<0:raise ValueError('shift must be nonnegative')
 if shift==0:return x
 return (1 if x>=0 else -1)*((abs(x)+(1<<(shift-1)))>>shift)

def epilogue(value,bias=0,multiplier=1,shift=0,relu=True):
 value=value+bias
 if relu:value=max(0,value)
 return max(-128,min(127,round_shift_away(value*multiplier,shift)))

def matmul(a,b):
 if not a or not b or not b[0]:raise ValueError('positive dimensions required')
 k=len(b);n=len(b[0])
 if any(len(r)!=k for r in a) or any(len(r)!=n for r in b):raise ValueError('shape mismatch')
 for row in a+b:
  for x in row:check_int8(x)
 result=[[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
 if any(not -(1<<31)<=x<(1<<31) for row in result for x in row):raise OverflowError('INT32 accumulation')
 return result

def array_model(a,b,r=4,c=4):
 """Clock-step accurate output-stationary tile; global stalls hold all state."""
 k=len(b);m=len(a);n=len(b[0]);assert m<=r and n<=c
 sums=[[0]*c for _ in range(r)];events=[]
 for t in range(k+r+c-2):
  active=[]
  for i in range(m):
   for j in range(n):
    q=t-i-j
    if 0<=q<k:
     p=a[i][q]*b[q][j];sums[i][j]+=p;active.append((i,j,q,p,sums[i][j]))
  events.append(active)
 return [row[:n] for row in sums[:m]],events

def tiled_matmul(a,b,tile=4,k_chunk=4):
 m=len(a);k=len(b);n=len(b[0]);out=[[0]*n for _ in range(m)]
 for i in range(0,m,tile):
  for j in range(0,n,tile):
   for q in range(0,k,k_chunk):
    aa=[row[q:q+k_chunk] for row in a[i:i+tile]];bb=[row[j:j+tile] for row in b[q:q+k_chunk]]
    partial,_=array_model(aa,bb,tile,tile)
    for ii,row in enumerate(partial):
     for jj,x in enumerate(row):out[i+ii][j+jj]+=x
 return out

class Memory:
 def __init__(self,size=4096):self.data=bytearray(size)
 def validate(self,addr,length,alignment=1):
  if not isinstance(addr,int) or addr<0 or length<0 or addr%alignment or length>len(self.data) or addr>len(self.data)-length:raise ValueError('invalid memory range/alignment')
 def write(self,addr,payload):self.validate(addr,len(payload));self.data[addr:addr+len(payload)]=payload
 def read(self,addr,length):self.validate(addr,length);return bytes(self.data[addr:addr+length])

@dataclass(frozen=True)
class Command:
 a:int;b:int;c:int;m:int;n:int;k:int

class Accelerator:
 """Functional transport model, not RTL DMA or an AXI implementation."""
 def __init__(self,memory):self.memory=memory;self.busy=False;self.done=False;self.error=None
 def submit(self,cmd):
  if self.busy:raise RuntimeError('busy')
  self.done=False;self.error=None
  if min(cmd.m,cmd.n,cmd.k)<=0:raise ValueError('positive dimensions required')
  for addr,length,align in [(cmd.a,cmd.m*cmd.k,1),(cmd.b,cmd.k*cmd.n,1),(cmd.c,cmd.m*cmd.n*4,4)]:self.memory.validate(addr,length,align)
  regions=[(cmd.a,cmd.a+cmd.m*cmd.k),(cmd.b,cmd.b+cmd.k*cmd.n),(cmd.c,cmd.c+cmd.m*cmd.n*4)]
  if any(max(regions[i][0],regions[j][0])<min(regions[i][1],regions[j][1]) for i,j in [(0,2),(1,2)]):raise ValueError('output overlaps input')
  self.busy=True
  try:
   a=list(struct.unpack(f'{cmd.m*cmd.k}b',self.memory.read(cmd.a,cmd.m*cmd.k)));b=list(struct.unpack(f'{cmd.k*cmd.n}b',self.memory.read(cmd.b,cmd.k*cmd.n)))
   result=tiled_matmul([a[i*cmd.k:(i+1)*cmd.k] for i in range(cmd.m)],[b[i*cmd.n:(i+1)*cmd.n] for i in range(cmd.k)])
   flat=[x for row in result for x in row];self.memory.write(cmd.c,struct.pack('<'+'i'*len(flat),*flat));self.done=True;return result
  except Exception as e:self.error=str(e);raise
  finally:self.busy=False

def mlp(x,w1,w2):
 h=[[epilogue(v,shift=1) for v in row] for row in tiled_matmul(x,w1)]
 return h,tiled_matmul(h,w2)
