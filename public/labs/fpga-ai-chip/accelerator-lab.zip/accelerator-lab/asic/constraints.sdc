create_clock -name core_clk -period 10.0 [get_ports clk]
set_input_delay 2.0 -clock core_clk [get_ports {rst start step_enable wr_en wr_addr* wr_data* m* n* k* rd_addr*}]
set_output_delay 2.0 -clock core_clk [get_ports {rd_data* busy done error}]
