# Educational Nangate45 target; not a foundry fabrication/signoff package.
LAB_ROOT := $(abspath $(dir $(lastword $(MAKEFILE_LIST)))/..)
export DESIGN_NAME = accelerator_top
export PLATFORM = nangate45
export VERILOG_FILES = $(LAB_ROOT)/rtl/pe.sv $(LAB_ROOT)/rtl/systolic_array.sv $(LAB_ROOT)/rtl/accelerator_top.sv
export SDC_FILE = $(LAB_ROOT)/asic/constraints.sdc
export CORE_UTILIZATION = 30
export PLACE_DENSITY = 0.40
export TNS_END_PERCENT = 100
