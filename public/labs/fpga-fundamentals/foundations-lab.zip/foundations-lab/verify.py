from pathlib import Path
import argparse,json,os,shutil,subprocess,tempfile,unittest
ROOT=Path(__file__).parent

def unsigned(v,w):return v&((1<<w)-1)
def signed(v,w):
 v=unsigned(v,w);return v-(1<<w) if v&(1<<(w-1)) else v

def matmul(x,w):
 if not x or not w or not x[0] or not w[0]:raise ValueError('nonempty matrices required')
 k=len(x[0]);n=len(w[0])
 if any(len(r)!=k for r in x) or len(w)!=k or any(len(r)!=n for r in w):raise ValueError('incompatible shapes')
 return [[sum(x[i][t]*w[t][j] for t in range(k)) for j in range(n)] for i in range(len(x))]

class Checks(unittest.TestCase):
 def test_unsigned(self):
  self.assertEqual(unsigned(0b101101,6),45)
  for v in range(64):self.assertEqual(sum(((v>>i)&1)*(1<<i) for i in range(6)),v)
 def test_signed(self):
  self.assertEqual(signed(0b111101,6),-3);self.assertEqual(signed(0b100000,6),-32)
  self.assertEqual({signed(v,6) for v in range(64)},set(range(-32,32)))
 def test_extension(self):
  for v in range(16):
   ext=v|0xf0 if v&8 else v
   self.assertEqual(signed(ext,8),signed(v,4));self.assertEqual(unsigned(v,8),v)
 def test_signed_overflow(self):
  for a in range(16):
   for b in range(16):
    full=signed(a,4)+signed(b,4);result=unsigned(a+b,4)
    by_sign=((a>>3)==(b>>3)) and ((result>>3)!=(a>>3))
    self.assertEqual(by_sign,not(-8<=full<=7))
  self.assertEqual(signed(7+1,4),-8)
 def test_dot(self):self.assertEqual(sum(a*b for a,b in zip([2,-1,3],[4,5,-2])),-3)
 def test_shapes(self):
  self.assertEqual(matmul([[1,2],[3,4]],[[5,6],[7,8]]),[[19,22],[43,50]])
  self.assertEqual(matmul([[1,2,3]],[[1,2],[3,4],[5,6]]),[[22,28]])
  with self.assertRaises(ValueError):matmul([[1,2]],[[1]])
 def test_gray(self):
  codes=[v^(v>>1) for v in range(8)]
  for a,b in zip(codes,codes[1:]+codes[:1]):self.assertEqual(bin(a^b).count('1'),1)
 def test_budgets(self):
  self.assertAlmostEqual(.4+3.2+.3+.2,4.1);self.assertAlmostEqual(.18-(.08+.04),.06)
  self.assertAlmostEqual(4.8+.9,5.7);self.assertAlmostEqual(2.4+.9,3.3)
  self.assertEqual(2*2*2,8);self.assertEqual(8*2,16);self.assertEqual(8//4,2)

def main():
 p=argparse.ArgumentParser();p.add_argument('--arithmetic-only',action='store_true');a=p.parse_args()
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
 if not result.wasSuccessful():raise SystemExit(1)
 report=dict(python_tests=result.testsRun,arithmetic='passed',rtl='not run',scope='Digital arithmetic and RTL simulation only. No board, synthesis, STA, analog metastability, or physical CDC signoff.')
 if not a.arithmetic_only:
  iv=os.environ.get('IVERILOG') or shutil.which('iverilog');vvp=os.environ.get('VVP') or shutil.which('vvp')
  if not iv or not vvp:raise SystemExit('Full verification requires iverilog and vvp; arithmetic-only is separately labeled.')
  with tempfile.TemporaryDirectory() as tmp:
   cmd=[iv,'-g2012','-s','tb','-o',str(Path(tmp)/'sim')]
   if os.environ.get('IVL_ROOT'):cmd+=['-B',os.environ['IVL_ROOT']]
   cmd += [str(ROOT/'foundations.sv'),str(ROOT/'tb.sv')]
   subprocess.run(cmd,check=True,cwd=tmp)
   run=subprocess.run([vvp,str(Path(tmp)/'sim')],check=True,cwd=tmp,text=True,capture_output=True);print(run.stdout)
   if 'PASS mux=32 adder=256 clocked_transitions=24' not in run.stdout:raise SystemExit('Missing complete RTL comparison report')
   shutil.copy2(Path(tmp)/'trace.vcd',ROOT/'trace.vcd')
   report.update(rtl='passed',mux_cases=32,adder_pairs=256,clocked_transitions=24,transcript=run.stdout,compile_command=cmd,run_command=[vvp,'sim'])
 (ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
