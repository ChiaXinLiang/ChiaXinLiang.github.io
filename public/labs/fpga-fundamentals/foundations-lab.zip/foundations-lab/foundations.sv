module mux2(input logic [1:0] a,b,input logic s,output logic [1:0] y);
  always_comb begin
    y=a;
    if(s) y=b;
  end
endmodule
module adder4(input logic [3:0] a,b,output logic [4:0] y);
  assign y={1'b0,a}+{1'b0,b};
endmodule
module pipeline2(input logic clk,reset,input logic [3:0] d,output logic [3:0] q1,q2);
  always_ff @(posedge clk) begin
    if(reset) begin q1<='0;q2<='0;end
    else begin q1<=d;q2<=q1;end
  end
endmodule
module enabled_register(input logic clk,reset,enable,input logic [3:0] d,output logic [3:0] q);
  always_ff @(posedge clk) begin
    if(reset) q<='0;
    else if(enable) q<=d;
  end
endmodule
