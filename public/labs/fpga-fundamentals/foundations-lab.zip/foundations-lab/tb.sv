`timescale 1ns/1ps
module tb;
  logic [1:0] ma=0,mb=0,my;logic ms=0;
  logic [3:0] a=0,b=0,d=0,q1,q2,q;
  logic [4:0] y;logic clk=0,reset=1,enable=0;
  integer i,j,k,mux_checks=0,adder_checks=0,state_checks=0;
  integer exp1=0,exp2=0,expq=0,old1;
  mux2 m(ma,mb,ms,my);adder4 ad(a,b,y);
  pipeline2 p(clk,reset,d,q1,q2);enabled_register e(clk,reset,enable,d,q);
  always #5 clk=~clk;
  task tick(input integer rst,en,val);
    begin
      @(negedge clk);reset=rst;enable=en;d=val;
      old1=exp1;
      if(rst) begin exp1=0;exp2=0;expq=0;end
      else begin exp1=val;exp2=old1;if(en)expq=val;end
      @(posedge clk);#1;
      if(q1 !== exp1[3:0] || q2 !== exp2[3:0] || q !== expq[3:0])
        $fatal(1,"state mismatch reset=%0d enable=%0d d=%0d expected=%0d,%0d,%0d got=%0d,%0d,%0d",rst,en,val,exp1,exp2,expq,q1,q2,q);
      state_checks=state_checks+1;
    end
  endtask
  initial begin
    $dumpfile("trace.vcd");$dumpvars(0,tb);
    for(i=0;i<4;i=i+1)for(j=0;j<4;j=j+1)for(k=0;k<2;k=k+1)begin
      ma=i;mb=j;ms=k;#1;
      if(my !== (k?mb:ma))$fatal(1,"mux a=%0d b=%0d s=%0d got=%0d",i,j,k,my);
      mux_checks=mux_checks+1;
    end
    for(i=0;i<16;i=i+1)for(j=0;j<16;j=j+1)begin
      a=i;b=j;#1;
      if(y !== (i+j))$fatal(1,"adder a=%0d b=%0d expected=%0d got=%0d",i,j,i+j,y);
      adder_checks=adder_checks+1;
    end
    tick(1,0,0);tick(0,1,3);tick(0,1,5);tick(0,0,9);
    tick(1,1,15);tick(0,0,7);tick(0,1,15);tick(0,0,0);
    for(i=0;i<16;i=i+1)tick(0,i%2,i);
    $display("PASS mux=%0d adder=%0d clocked_transitions=%0d",mux_checks,adder_checks,state_checks);
    $finish;
  end
endmodule
