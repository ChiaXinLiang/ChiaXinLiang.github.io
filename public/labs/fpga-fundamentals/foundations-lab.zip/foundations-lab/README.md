# Digital hardware and FPGA foundations lab

Original educational examples accompanying the FPGA & Digital Hardware Fundamentals series.

## Requirements and commands

Use Python 3.9+ and Icarus Verilog with SystemVerilog support (`iverilog`, `vvp`). Run:

```sh
python3 verify.py
```

The full command fails if the simulator is missing. An independently labeled arithmetic-only run is available:

```sh
python3 verify.py --arithmetic-only
```

Optional `IVERILOG`, `VVP`, and `IVL_ROOT` environment variables select an existing simulator installation. `IVL_ROOT` is only needed for a relocated Icarus installation.

## Contents and evidence

- `foundations.sv`: unsigned two-bit mux, explicitly widened unsigned adder, two-register pipeline, and enabled register with synchronous active-high reset.
- `tb.sv`: exhaustive 32-case mux and 256-pair adder checks, 24 clocked reset/enable/old-state transitions, mismatch failures, and VCD output.
- `verify.py`: eight Python tests covering bit weights, two's complement, extension, signed overflow over 256 pairs, dot product, compatible/non-square matrix shapes, Gray transitions, and illustrative timing/schedule budgets.
- `verification.json`: actual full-run report for this release; rerunning regenerates it.
- `trace.vcd`: waveform from the included full RTL simulation.

The testbench drives clocked inputs at falling edges and samples after rising-edge nonblocking updates. Its simulation delays are not device timing constraints. The two-register pipeline has no ready/valid or stall protocol.

Evidence is limited to digital arithmetic and RTL simulation. No synthesis, placement/routing, static timing analysis, physical CDC signoff, analog metastability modeling, FPGA board programming, or ASIC fabrication is claimed. Gray-code arithmetic does not verify a complete asynchronous FIFO. One-MAC/four-lane counts are ideal analytical compute schedules, excluding IO and pipeline overhead.

Change the reference contract independently of the DUT when adapting examples. Keep compile and execution results, comparison counts, and the distinction between arithmetic-only and full verification.
